package com.example.deber_02db.activity

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.deber_02db.R
import com.example.deber_02db.model.Auto
import com.example.deber_02db.repository.AutoRepository
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.text.SimpleDateFormat
import java.util.*

class AutoFormActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var autoRepository: AutoRepository
    private lateinit var etNombre: EditText
    private lateinit var etMarca: EditText
    private lateinit var etPrecio: EditText
    private lateinit var etFechaFabricacion: EditText
    private lateinit var btnGuardar: Button
    private lateinit var tvCoordenadas: TextView

    private lateinit var googleMap: GoogleMap
    private var selectedLat: Double = 0.0
    private var selectedLng: Double = 0.0

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auto_form)

        autoRepository = AutoRepository(this)
        etNombre = findViewById(R.id.etNombreAuto)
        etMarca = findViewById(R.id.etMarcaAuto)
        etPrecio = findViewById(R.id.etPrecioAuto)
        etFechaFabricacion = findViewById(R.id.etFechaFabricacion)
        btnGuardar = findViewById(R.id.btnGuardarAuto)
        tvCoordenadas = findViewById(R.id.tvCoordenadas)

        val autoId = intent.getIntExtra("autoId", -1)
        val parteId = intent.getIntExtra("parteId", -1)
        if (parteId != -1) {
            cargarAuto(autoId)
        }

        // Configurar el fragmento del mapa
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Acción del botón Guardar
        btnGuardar.setOnClickListener {
            if (validarCampos()) {
                val nombre = etNombre.text.toString()
                val marca = etMarca.text.toString()
                val precio = etPrecio.text.toString().toDoubleOrNull() ?: 0.0  // Asegúrate de no tener nulos

                val fechaFabricacion = try {
                    dateFormat.parse(etFechaFabricacion.text.toString()) ?: Date()
                } catch (e: Exception) {
                    Toast.makeText(this, "Formato de fecha incorrecto", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                // Verifica las coordenadas antes de guardar
                if (selectedLat == 0.0 && selectedLng == 0.0) {
                    Toast.makeText(this, "Por favor selecciona una ubicación en el mapa", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val auto = Auto(
                    id = 0,
                    nombre = nombre,
                    marca = marca,
                    precio = precio,
                    fechaFabricacion = fechaFabricacion,
                    latitud = selectedLat,
                    longitud = selectedLng
                )

                if (autoRepository.insertarAuto(auto) > 0) {
                    Toast.makeText(this, "Auto guardado con éxito", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Error al guardar el auto", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Mover la cámara a una ubicación inicial (Quito por ejemplo)
        val ubicacionInicial = LatLng(-0.180653, -78.467834)
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(ubicacionInicial, 15f))

        // Detectar clics en el mapa
        googleMap.setOnMapClickListener { latLng ->
            googleMap.clear()  // Limpiar marcadores previos
            googleMap.addMarker(MarkerOptions().position(latLng).title("Ubicación seleccionada"))
            selectedLat = latLng.latitude
            selectedLng = latLng.longitude

            // Actualizar el texto con las coordenadas seleccionadas
            tvCoordenadas.text = "Latitud: $selectedLat, Longitud: $selectedLng"
        }
    }

    private fun cargarAuto(autoId: Int) {
        val parte = autoRepository.obtenerPorId(autoId)
        parte?.let {
            etNombre.setText(it.nombre)
            etMarca.setText(it.marca)
            etPrecio.setText(it.precio.toString())
            etFechaFabricacion.setText(it.fechaFabricacion.toString()) // Convertir correctamente la fecha
            tvCoordenadas.text = "Latitud: ${it.latitud}, Longitud: ${it.longitud}"
        }
    }

    private fun validarCampos(): Boolean {
        val nombre = etNombre.text.toString().trim()
        val marca = etMarca.text.toString().trim()
        val precio = etPrecio.text.toString().trim()
        val fechaFabricacion = etFechaFabricacion.text.toString().trim()

        return when {
            nombre.isEmpty() -> {
                etNombre.error = "El nombre es obligatorio"
                false
            }
            marca.isEmpty() -> {
                etMarca.error = "La marca es obligatoria"
                false
            }
            precio.isEmpty() -> {
                etPrecio.error = "El precio es obligatorio"
                false
            }
            fechaFabricacion.isEmpty() -> {
                etFechaFabricacion.error = "La fecha es obligatoria"
                false
            }
            else -> true
        }
    }
}
